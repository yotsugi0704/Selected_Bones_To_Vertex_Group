import bpy
from bpy.types import Operator,Panel,Menu

	
class Add_Selected_VGroup(Operator):
	bl_idname = "wm.add_vgroup_to_select"
	bl_label = "Add To Vertex Group"


	@classmethod
	def poll(self,context):
		hasmesh = False
		if context.selected_objects:
			select_obj = context.selected_objects
			for obj in select_obj:
				if obj.type=="MESH":
					hasmesh = True
					break
		return (context.active_object is not None) and (context.active_object.type =="ARMATURE") and hasmesh

	def execute(self,context):
		select_obj = bpy.context.selected_objects
		active_obj = bpy.context.active_object

		if active_obj.type == "ARMATURE":

			bpy.ops.object.mode_set(mode = "EDIT")
			select_mesh = set()
			select_bone = set()
			Bone = active_obj.data.edit_bones
			active_bone = Bone.active

			if active_bone:
				name = active_bone.name
				bone = Bone[name]
				if bone.use_deform:
					select_bone.add(active_bone)
			for bone in Bone:
				if bone.select and bone.use_deform:
					select_bone.add(bone)

			for obj in select_obj:
				if obj.type != 'MESH':
					pass
					continue
				if obj.type == "MESH":
					select_mesh.add(obj)
					continue

			for obj in select_mesh:
				has_mod = False
				for mod in obj.modifiers:
					if mod.type == "ARMATURE" and mod.object == active_obj:
						has_mod = True
						break
				if not has_mod:
					add_armature_mod(active_obj,obj)
				
				for bone in select_bone:
					Vgroup = obj.vertex_groups.get(bone.name)
					if not Vgroup:
						vgroup = obj.vertex_groups.new(name=bone.name)
						
			bpy.ops.object.mode_set(mode = "OBJECT")


			return{'FINISHED'}
		else:	
			print("no active armature.")
			warning("Need Active Armature!")
			return{'CANCELLED'}

class Delete_Selected_VGroup(Operator):
	bl_idname = "wm.delete_vgroup_to_select"
	bl_label = "Delete From Vertex Group"
	
	@classmethod
	def poll(self,context):
		hasmesh = False
		if context.selected_objects:
			select_obj = context.selected_objects
			for obj in select_obj:
				if obj.type=="MESH":
					hasmesh = True
					break
		return (context.active_object is not None) and (context.active_object.type =="ARMATURE") and hasmesh
	def execute(self,context):
		select_obj = bpy.context.selected_objects
		active_obj = bpy.context.active_object
		if active_obj.type == "ARMATURE":

			bpy.ops.object.mode_set(mode = "EDIT")
			select_mesh = set()
			select_bone = set()
			Bone = active_obj.data.edit_bones
			active_bone = Bone.active
			
			if active_bone:
				select_bone.add(active_bone)
			for bone in Bone:
				if bone.select:
					select_bone.add(bone)

			for obj in select_obj:
				if obj.type != 'MESH':
					pass
					continue
				if obj.type == "MESH":
					select_mesh.add(obj)
					continue
			for obj in select_mesh:
				for bone in select_bone:
					if bone.name in obj.vertex_groups:
						vg_name = obj.vertex_groups[bone.name]
						obj.vertex_groups.remove(vg_name)

			bpy.ops.object.mode_set(mode = "OBJECT")

			return{'FINISHED'}
		
def add_armature_mod(active_obj,obj):	
	if active_obj.type == "ARMATURE":
		mod_name = active_obj.name
		new_mod = obj.modifiers.new(name = mod_name,type ="ARMATURE")
		new_mod.object = active_obj
		return


def warning(message = "",title = "Warning",icon = "INFO"):
	def draw(self,context):
		self.layout.label(text=message)
	bpy.context.window_manager.popup_menu(draw,title = title,icon = icon)
#------------------------------------------------------------------------
class OBJECT_MT_draw_menu(Menu):
	bl_idname = "object.add_del_menu"
	bl_label = "Selected Bones to Vertex Group"

	def draw(self,context):
		layout = self.layout
		layout.operator(Add_Selected_VGroup.bl_idname)
		layout.operator(Delete_Selected_VGroup.bl_idname)


def draw_menu(self,context):
	self.layout.menu(OBJECT_MT_draw_menu.bl_idname)

def register():
	bpy.utils.register_class(OBJECT_MT_draw_menu)
	bpy.utils.register_class(Add_Selected_VGroup)
	bpy.utils.register_class(Delete_Selected_VGroup)
	bpy.types.VIEW3D_MT_object_parent.append(draw_menu)
	bpy.types.VIEW3D_MT_object_context_menu.append(draw_menu)
	
def unregister():
	bpy.types.VIEW3D_MT_object_context_menu.remove(draw_menu)
	bpy.types.VIEW3D_MT_object_parent.remove(draw_menu)
	bpy.utils.unregister_class(Delete_Selected_VGroup)
	bpy.utils.unregister_class(Add_Selected_VGroup)
	bpy.utils.unregister_class(OBJECT_MT_draw_menu)
	
#if __name__ =="__main__":
#	register()