from.Selected_Bones_to_Vertex_Group import register,unregister

bl_info = {
    "name": "Select VertexGroup Tool",
    "author": "Mochi Lin",
    "version": (1, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Objects > Parent > Armature Deform > With Empty Group(Use Select bone)",
    "description": "add/delete selected bone to vertex group",
    "warning": "",
    "doc_url": "",
    "category": "Rigging",
}
